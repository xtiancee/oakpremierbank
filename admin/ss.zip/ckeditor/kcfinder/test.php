<script src="../kcfinder/ckeditor/ckeditor.js"></script>
	<script src="../kcfinder/ckeditor/samples/js/sample.js"></script>
	<link rel="stylesheet" href="../kcfinder/ckeditor/css/samples.css">
	<link rel="stylesheet" href="../kcfinder/ckeditor/samples/toolbarconfigurator/lib/codemirror/neo.css">
		<script src="js/jquery.min.js"></script>
 <textarea id="editor1"></textarea>
 
 <script type="text/javascript">

		// Activate the plugin
	CKEDITOR.replace('editor1', {
			
		})

	</script>
	